function toggle(e) {
  var x = document.getElementById(e);
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
