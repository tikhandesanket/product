$(document).ready(function() {
    let $sn = 1;
    $('#addMoreRooms').on('click', function(e) {
        $sn++;
        e.preventDefault();
        // $('#stbRoomsBody').append('<tr><td>111</td></tr>');
        // $('#stbRoomsBody').append('<tr class="appended-row" id="row'+ $sn+'"><td>'+ $sn +'</td><td class="stbData"><div class="user-box"><input type="text" name="room-no" required=""><label> Room No.</label></div></td><td class="stbData"><div class="user-box"><input type="text" name="serial-no" required=""><label> Serial No.</label></div></td><td class="stbData"><div class="user-box"><input type="radio" name="stb-status"> <span class="radio-label">Active</span><input type="radio" name="stb-status"> <span class="radio-label">Inactive</span></div></td><td><div class="stb-actions mb-3"><button type="button" class="stb-action-btn stbSave inactive"><img src="../assets/images/check-icon-save.png" alt="Save Data"></button><button class="stb-action-btn stbEdit inactive"><img src="../assets/images/edit.svg" alt=""></button><button class="stb-action-btn delete_btn " id="'+$sn+'"><img src="../assets/images/delete.svg" alt=""></button></div></td></tr>');
        
        
        $('#stbRoomsBody').append('<tr class="appended-row" id="row'+ $sn+'"><td>'+ $sn +'</td><td class="stbData"><div class="user-box"><input type="text" name="room-no[]" Placeholder="Room No" required=""></div></td><td class="stbData"><div class="user-box"><input type="text" name="serial-no[]" placeholder="Serial No." required=""></div></td><td class="stbData"><div class="user-box"><input type="radio" name="stb-status[]" value="Active"> <span class="radio-label">Active</span><input type="radio" name="stb-status[]" value="Inactive"> <span class="radio-label">Inactive</span></div></td><td><div class="stb-actions mb-3"><button type="button" class="stb-action-btn stbSave"><img src="../assets/images/check-icon-save.png" alt="Save Data"></button><button class="stb-action-btn stbEdit inactive"><img src="../assets/images/edit.svg" alt=""></button><button class="stb-action-btn delete_btn " id="'+$sn+'"><img src="../assets/images/delete.svg" alt=""></button></div></td></tr>');
        $('.radio-label').show();
        $('.stbEdit').hide();
    })

    $(document).on('click', '.delete_btn', function(e){
        e.preventDefault();
        var button_id = $(this).attr("id");
        $('#row'+button_id+'').remove();
    });


});

// edit inline stb stbData
$(document).on('click', '.stbEdit', function(e) {
    e.preventDefault();
    $(this).parent().parent().siblings('td.stbData').each(function() {
        // console.log(this);
      var content = $(this).children().html();
    //   console.log('<br>'+content);
      $(this).children().html('<input value="' + content + '" />');
    });
    
    $(this).siblings('.stbSave').show();
    $(this).siblings('.stbDelete').hide();
    $(this).hide();
  });
  
  $(document).on('click', '.stbSave', function() {

    var radioValue = $("input[name='stb-status']:checked").val();
    console.log(radioValue);
    
    $('input').each(function() {
      var content = $(this).val();
      $(this).html(content);
      $(this).contents().unwrap();
    });
    $(this).siblings('.stbEdit').show();
    $(this).siblings('.delete').show();
    $(this).hide();
    $('.radio-label').hide();
    
  });
  
